
import Quiz from "./components/quizcard";

function App() {
  return (
    <div className="flex justify-center">
      
      <Quiz name="Wello" />
    </div>
  );
}

export default App;
