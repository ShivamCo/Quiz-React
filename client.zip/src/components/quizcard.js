import { useEffect, useState } from "react";
import data from "../json/questions.json";
import { CircularProgressbar } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';
import Progress from 'react-progressbar'



const Quiz = () => {


    let [number, setNumber] = useState({ num: 0 })
    const [currentQuestion, setCurrentQuestion] = useState(data[number.num])
    const [score, setScore] = useState({ score: 0 })
    let [answer, setAnswer] = useState('');
    const [count, setCount] = useState(100);

    const handleChange = (event) => {

        setAnswer(event.target.value)
    }

    const nextClickHandler = (event) => {
        event.preventDefault()

        let n = number.num - 1
        console.log((data[n]).answer)

        if (answer == data[n].answer) {
            setScore({ ...score, score: score.score + 1 })
        } else {

            setScore({ ...score, score: score.score })

        }

        setCurrentQuestion(data[number.num])
        numberPlus()
        setCount(100)
    }




    const numberPlus = () => {

        setNumber({ ...number, num: number.num + 1 })
    }

    useEffect(() => {
        numberPlus()



    }, [])

    useEffect(() => {
        const interval = setInterval(() => {
            setCount(count - 1);
        }, 1000);


    }, [count])

    console.log(score)
    console.log(number.num)




    return (
        <>

            <div className="border-2 sm:w-1/3 w-full rounded-lg m-4">
                <div className=" overflow-hidden " >
                    <Progress completed={number.num * 10} />
                   

                </div>

                {
                    number.num <= data.length

                        ?


                        <div>
                        <div className="flex justify-center p-2" >
                        <div className="flex justify-center"
                            style={{ width: 50, height: 50 }}>
                            <CircularProgressbar text={`${count}`} value={(count)} />
                        </div>
                    </div>
                            <div className="flex m-2 shadow-md  rounded-md bg-sky-800 " >
                                <div className="flex-none sm:text-xl text-md m-2 text-sky-50 " ></div>
                                <div className="flex-auto sm:text-xl text-md m-2 text-white font-semibold  ">{currentQuestion.question}</div>

                            </div>



                            <form className="flex m-4 justify-center flex-col " >
                                <div className="flex justify-center " >
                                    <ul className="w-48 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                                        {
                                            (currentQuestion.options).map((i) =>
                                                <li className="w-full border-b border-gray-200 rounded-t-lg dark:border-gray-600">
                                                    <div className="flex items-center pl-3">
                                                        <input type="radio" onChange={handleChange} value={i} name="list-radio" className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-700 dark:focus:ring-offset-gray-700 focus:ring-2 dark:bg-gray-600 dark:border-gray-500" dselect />
                                                        <label className="w-full py-3 ml-2 text-sm font-medium text-gray-900 dark:text-gray-300">{i}</label>
                                                    </div>
                                                </li>
                                            )
                                        }



                                    </ul>
                                </div>
                                <div className="flex justify-center " >
                                    <button
                                        onClick={nextClickHandler}
                                        className="  m-4 mt-8 rounded-md p-2 text-lg font-semibold text-white bg-sky-500 shadow-lg pr-6 pl-6 " type="submit">Next</button>
                                </div>
                            </form>
                        </div>








                        :

                        <div className="flex flex-col border-2 justify-center  m-4 rounded-lg">
                            <div className="flex justify-center p-2 ">
                                <p className=" text-2xl text-blue-400 font-semibold " >Score is:</p>
                                <h5 className=" text-3xl pl-2 font-semibold" >{score.score}</h5>


                            </div>
                            <div className="flex justify-center p-2" >
                                <div className="flex justify-center p-2"
                                    style={{ width: 200, height: 200 }}>
                                    <CircularProgressbar text={`${score.score * 10}%`} value={score.score * 10} />
                                </div>
                            </div>
                            <div className="flex justify-center p-2" >
                                <a href="/" className=" drop-shadow-md hover:bg-sky-700 p-1 pr-2 pl-2 text-lg font-semibold text-white bg-sky-400 rounded-lg " >Try Again</a>
                            </div>
                        </div>



                }


            </div>
        </>

    )





}


export default Quiz